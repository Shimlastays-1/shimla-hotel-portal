# SHIMLA STAYS backend setup

## 1) Database
Run `00-full-database-setup.sql` (in the project root) once in the Supabase SQL Editor. It creates every
table, RLS policy, storage bucket and function the website needs, in one go — safe to re-run later if you
ever update it. See the comments at the end of that file for how to make your own account an admin.

## 2) What works with ZERO backend configuration (already live)
- Guest gets an instant **Booking Reference** on screen the moment they book, plus buttons to copy it or
  share/save the confirmation (native share sheet, falls back to copy-to-clipboard).
- Guest can track their booking anytime from "My Booking" using the reference + phone.
- Guest has a one-tap **"Notify Admin via WhatsApp"** button that opens WhatsApp with all booking details
  pre-filled to `7559772533` — the guest just taps Send. This works on every phone, no setup required.
- Admin panel > Bookings has a **"Message Guest"** button that opens WhatsApp to that guest's number.
- The floating "Trip Help & WhatsApp Quote" popup and the mobile bottom Call/WhatsApp bar work immediately.

## 3) Fully automatic notifications (optional, needs one-time setup)
Browsers cannot silently send a WhatsApp message on someone's behalf — only the buttons above (which the
guest taps) are possible without a backend. For a message to be sent automatically, without anyone tapping
anything, you need one of the two integrations below. Both are already wired into the website; they just
need credentials.

### 3a) WhatsApp Cloud API (Meta) — automatic message to YOUR WhatsApp
Deploy `send-booking-whatsapp`, then set these Supabase Edge Function secrets:
- `WHATSAPP_ACCESS_TOKEN` — Meta permanent/system-user access token
- `WHATSAPP_PHONE_NUMBER_ID` — Meta WhatsApp API phone number ID
- `WHATSAPP_ADMIN_NUMBER` — `7559772533`
- `WHATSAPP_TEMPLATE_NAME` — your approved admin template name (default `new_booking_notification`)
- `WHATSAPP_TEMPLATE_LANGUAGE` — template language code (default `en_US`)
- `WHATSAPP_API_VERSION` — Meta Graph API version currently supported by your Meta app

The approved admin template must contain **9 body variables**, in this order:
1 booking reference, 2 guest name, 3 hotel, 4 room, 5 check-in, 6 check-out, 7 total, 8 20% advance, 9 balance.

**Optional — automatic confirmation to the GUEST's own WhatsApp too:** Meta requires a *separate*,
pre-approved template to message a guest who hasn't messaged you first. Once you have that template
approved, set:
- `WHATSAPP_GUEST_TEMPLATE_NAME` — your approved guest-facing template name
- `WHATSAPP_GUEST_TEMPLATE_LANGUAGE` — optional, defaults to the admin template's language

Guest template must contain **5 body variables**, in this order: booking reference, guest name, hotel,
check-in, check-out. If this variable isn't set, the guest WhatsApp step is simply skipped — nothing breaks.

### 3b) Email (Resend) — automatic confirmation to admin and/or guest email
Deploy `send-booking-email` and set:
- `RESEND_API_KEY`
- `RESEND_FROM` — a sender address on your verified Resend domain
- `ADMIN_EMAIL` — optional; if set, the admin also gets an email copy of every booking

If a guest enters their email at booking time, they automatically get an email confirmation with their
reference number and status — no extra setup beyond the two keys above. Note: Resend's free tier only
delivers to arbitrary recipients once you verify a sending domain; until then it may only deliver to your
own verified test address.

## 4) Deploy
Use the Supabase CLI or the dashboard's Edge Functions deployment flow. The website calls both functions
right after a booking is created, and again when the admin confirms a room or verifies payment — all as
best-effort background calls. If the functions aren't deployed/configured yet, bookings still succeed
normally; only the extra automatic notification step is skipped.

## 5) Even more reliable: a database trigger
For notifications that fire even if the guest's browser closes immediately after booking, add a Supabase
Database Webhook (or trigger) on `public.bookings` INSERT/UPDATE to invoke `send-booking-whatsapp` and
`send-booking-email` server-side. The frontend calls remain as a first, immediate attempt either way.

## Payment
The site keeps the 20% UPI QR flow. Guests submit a UTR/reference after paying; admin marks it `paid` or
`rejected` from the Bookings tab. A plain UPI QR does not give automatic bank-side confirmation — that
would need a payment gateway with webhooks (e.g. Razorpay/Cashfree), which is a bigger integration than
what's included here.
