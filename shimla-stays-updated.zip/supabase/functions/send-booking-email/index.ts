import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type'}

async function sendEmail(key: string, from: string, to: string, subject: string, html: string) {
  const r = await fetch('https://api.resend.com/emails', {
    method:'POST', headers:{ Authorization:`Bearer ${key}`, 'Content-Type':'application/json' },
    body: JSON.stringify({ from, to:[to], subject, html })
  })
  const out = await r.json()
  if (!r.ok) throw new Error(out?.message || 'Resend failed')
  return out
}

Deno.serve(async(req)=>{
 if(req.method==='OPTIONS') return new Response('ok',{headers:cors})
 let booking_id: string | undefined
 try{
  ;({ booking_id } = await req.json()); if(!booking_id) throw new Error('booking_id is required')
  const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const {data:b,error}=await admin.from('bookings').select('*, hotels(name), rooms(name)').eq('id',booking_id).single(); if(error) throw error
  const key=Deno.env.get('RESEND_API_KEY'); const adminTo=Deno.env.get('ADMIN_EMAIL'); const from=Deno.env.get('RESEND_FROM')
  if(!key||!from) throw new Error('Resend email secrets are not configured')

  const total=Number(b.total_amount||0), advance=Number(b.advance_amount||Math.round(total*.2*100)/100)
  const hotel = b.hotels?.name||'', room = b.rooms?.name||''

  let adminResult: unknown = null, guestResult: unknown = null

  // 1) Admin copy (as before).
  if (adminTo) {
    const adminHtml=`<h2>New SHIMLA STAYS booking</h2><p><b>Reference:</b> ${b.booking_ref}</p><p><b>Guest:</b> ${b.guest_name}<br><b>Phone:</b> ${b.phone}<br><b>Hotel:</b> ${hotel}<br><b>Room:</b> ${room}<br><b>Dates:</b> ${b.check_in} → ${b.check_out}<br><b>Total:</b> ₹${total.toFixed(2)}<br><b>Advance 20%:</b> ₹${advance.toFixed(2)}</p>`
    try { adminResult = await sendEmail(key, from, adminTo, `New booking ${b.booking_ref}`, adminHtml) }
    catch (ae) { await admin.from('bookings').update({ email_notification_status:'failed', email_notification_error:String((ae as Error)?.message||ae) }).eq('id',booking_id) }
  }

  // 2) Guest confirmation copy — sent automatically if the guest provided an email at booking time.
  if (b.email) {
    const guestHtml=`<h2>Your SHIMLA STAYS booking is received</h2>
      <p>Hi ${b.guest_name},</p>
      <p>Thanks for booking with SHIMLA STAYS. Here are your details:</p>
      <p><b>Reference:</b> ${b.booking_ref}<br><b>Hotel:</b> ${hotel}<br><b>Room:</b> ${room}<br><b>Dates:</b> ${b.check_in} → ${b.check_out}<br><b>Guests:</b> ${b.guests}<br><b>Total:</b> ₹${total.toFixed(2)}<br><b>20% Advance:</b> ₹${advance.toFixed(2)}</p>
      <p>Current status: <b>${b.status}</b> / Payment: <b>${b.payment_status || 'pending'}</b></p>
      <p>You can track this booking anytime on the SHIMLA STAYS website using your reference number and phone number.</p>
      <p>— SHIMLA STAYS</p>`
    try {
      guestResult = await sendEmail(key, from, b.email, `Your SHIMLA STAYS booking ${b.booking_ref}`, guestHtml)
      await admin.from('bookings').update({ email_notification_status:'sent', email_notification_error:null }).eq('id',booking_id)
    } catch (ge) {
      await admin.from('bookings').update({ email_notification_status:'failed', email_notification_error:String((ge as Error)?.message||ge) }).eq('id',booking_id)
    }
  }

  return new Response(JSON.stringify({ok:true,admin:adminResult,guest:guestResult}),{headers:{...cors,'Content-Type':'application/json'}})
 }catch(e){
  return new Response(JSON.stringify({ok:false,error:String((e as Error)?.message||e)}),{status:400,headers:{...cors,'Content-Type':'application/json'}})
 }
})
