import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const cors = { 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type' }

async function sendTemplate(token: string, phoneNumberId: string, version: string, to: string, template: string, lang: string, params: string[]) {
  const body = {
    messaging_product: 'whatsapp', to, type: 'template',
    template: { name: template, language: { code: lang }, components: [{ type: 'body', parameters: params.map(text => ({ type: 'text', text })) }] }
  }
  const resp = await fetch(`https://graph.facebook.com/${version}/${phoneNumberId}/messages`, {
    method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  })
  const result = await resp.json()
  if (!resp.ok) throw new Error(result?.error?.message || 'WhatsApp API request failed')
  return result
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok',{headers:cors})
  let booking_id: string | undefined
  try {
    ;({ booking_id } = await req.json())
    if (!booking_id) throw new Error('booking_id is required')

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
    const { data:b, error } = await admin.from('bookings').select('*, hotels(name), rooms(name)').eq('id',booking_id).single()
    if (error) throw error

    const token = Deno.env.get('WHATSAPP_ACCESS_TOKEN')
    const phoneNumberId = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID')
    const version = Deno.env.get('WHATSAPP_API_VERSION') || 'v23.0'
    if (!token || !phoneNumberId) throw new Error('WhatsApp secrets are not configured')

    const total = Number(b.total_amount || 0)
    const advance = Number(b.advance_amount || Math.round(total*0.20*100)/100)
    const balance = Number(b.balance_amount || total-advance)
    const hotel = b.hotels?.name || ''
    const room = b.rooms?.name || ''

    // 1) Admin notification (required). Template must have 9 body variables in this order:
    // ref, guest name, hotel, room, check-in, check-out, total, advance, balance.
    const adminRecipient = (Deno.env.get('WHATSAPP_ADMIN_NUMBER') || '7559772533').replace(/\D/g,'')
    const adminTemplate = Deno.env.get('WHATSAPP_TEMPLATE_NAME') || 'new_booking_notification'
    const adminLang = Deno.env.get('WHATSAPP_TEMPLATE_LANGUAGE') || 'en_US'
    const adminResult = await sendTemplate(token, phoneNumberId, version, adminRecipient, adminTemplate, adminLang, [
      String(b.booking_ref||''), String(b.guest_name||''), String(hotel), String(room),
      String(b.check_in||''), String(b.check_out||''), total.toFixed(2), advance.toFixed(2), balance.toFixed(2)
    ])
    await admin.from('bookings').update({ whatsapp_notification_status:'sent', whatsapp_notification_error:null }).eq('id',booking_id)

    // 2) Guest confirmation (optional). Only attempted if a guest-facing template name is configured
    // AND the booking has a phone number. Meta requires this template to be pre-approved separately,
    // since business-initiated messages to a guest's personal number must use an approved template too.
    // Suggested guest template variables (5): ref, guest name, hotel, check-in, check-out.
    let guestResult: unknown = null
    const guestTemplate = Deno.env.get('WHATSAPP_GUEST_TEMPLATE_NAME')
    if (guestTemplate && b.phone) {
      try {
        const guestRecipient = '91' + String(b.phone).replace(/\D/g,'').slice(-10)
        const guestLang = Deno.env.get('WHATSAPP_GUEST_TEMPLATE_LANGUAGE') || adminLang
        guestResult = await sendTemplate(token, phoneNumberId, version, guestRecipient, guestTemplate, guestLang, [
          String(b.booking_ref||''), String(b.guest_name||''), String(hotel), String(b.check_in||''), String(b.check_out||'')
        ])
        await admin.from('bookings').update({ guest_whatsapp_status:'sent', guest_whatsapp_error:null }).eq('id',booking_id)
      } catch (ge) {
        await admin.from('bookings').update({ guest_whatsapp_status:'failed', guest_whatsapp_error:String((ge as Error)?.message||ge) }).eq('id',booking_id)
      }
    }

    return new Response(JSON.stringify({ ok:true, admin:adminResult, guest:guestResult }),{headers:{...cors,'Content-Type':'application/json'}})
  } catch (e) {
    if (booking_id) {
      try {
        const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
        await admin.from('bookings').update({ whatsapp_notification_status:'failed', whatsapp_notification_error:String((e as Error)?.message||e) }).eq('id',booking_id)
      } catch {}
    }
    return new Response(JSON.stringify({ok:false,error:String((e as Error)?.message||e)}),{status:400,headers:{...cors,'Content-Type':'application/json'}})
  }
})
