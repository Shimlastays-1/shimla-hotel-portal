-- =====================================================================================
-- SHIMLA STAYS — Complete Supabase Database Setup
-- =====================================================================================
-- Run this ENTIRE file once in Supabase Dashboard → SQL Editor → New query → Run.
--
-- Safe to re-run: every statement uses IF NOT EXISTS / OR REPLACE / DROP POLICY IF EXISTS
-- style guards, so running this again later (e.g. after an update) will not duplicate
-- data or error out on things that already exist.
--
-- This single file replaces the earlier "addons.sql" + "addons2-leads.sql" — you do not
-- need those anymore if you run this one.
-- =====================================================================================


-- =====================================================================================
-- SECTION 1: EXTENSIONS
-- =====================================================================================
create extension if not exists pgcrypto;  -- gives us gen_random_uuid()


-- =====================================================================================
-- SECTION 2: PROFILES (links to Supabase Auth users, stores role)
-- =====================================================================================
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'guest' check (role in ('guest','admin')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "user can read own profile" on public.profiles;
create policy "user can read own profile"
  on public.profiles for select
  to authenticated
  using (id = auth.uid());

drop policy if exists "admin can read all profiles" on public.profiles;
create policy "admin can read all profiles"
  on public.profiles for select
  to authenticated
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

-- Auto-create a profile row (role='guest') whenever someone signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, new.raw_user_meta_data->>'full_name', 'guest')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- NOTE: To make an account an admin, run this manually after the person signs up once:
--   update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'you@example.com');
-- There is deliberately no client-side way to change role — only you, in the SQL editor, can promote an admin.


-- =====================================================================================
-- SECTION 3: HOTELS, ROOMS, IMAGES
-- =====================================================================================
create table if not exists public.hotels (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  location text,
  address text,
  phone text,
  description text,
  amenities text[] not null default '{}',
  image_url text,
  gallery_images text[] not null default '{}',
  video_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid not null references public.hotels(id) on delete cascade,
  name text not null,
  price numeric(12,2) not null default 0,
  capacity integer not null default 2,
  bed_type text,
  total_rooms integer not null default 0,
  image_url text,
  image_urls text[] not null default '{}',
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.hotel_images (
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid not null references public.hotels(id) on delete cascade,
  image_url text not null,
  alt_text text,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.room_images (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  image_url text not null,
  alt_text text,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.room_units (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  room_number text not null,
  status text not null default 'available' check (status in ('available','maintenance')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (room_id, room_number)
);

create index if not exists rooms_hotel_id_idx on public.rooms(hotel_id);
create index if not exists hotel_images_hotel_id_idx on public.hotel_images(hotel_id);
create index if not exists room_images_room_id_idx on public.room_images(room_id);
create index if not exists room_units_room_id_idx on public.room_units(room_id);

alter table public.hotels enable row level security;
alter table public.rooms enable row level security;
alter table public.hotel_images enable row level security;
alter table public.room_images enable row level security;
alter table public.room_units enable row level security;

-- Helper: is the current user an admin? Used repeatedly below.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- Public (anon + logged in) can see only ACTIVE hotels/rooms/images. Admin sees everything.
drop policy if exists "public can read active hotels" on public.hotels;
create policy "public can read active hotels" on public.hotels for select to anon, authenticated using (active = true or public.is_admin());
drop policy if exists "admin can write hotels" on public.hotels;
create policy "admin can write hotels" on public.hotels for insert to authenticated with check (public.is_admin());
drop policy if exists "admin can update hotels" on public.hotels;
create policy "admin can update hotels" on public.hotels for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin can delete hotels" on public.hotels;
create policy "admin can delete hotels" on public.hotels for delete to authenticated using (public.is_admin());

drop policy if exists "public can read active rooms" on public.rooms;
create policy "public can read active rooms" on public.rooms for select to anon, authenticated using (active = true or public.is_admin());
drop policy if exists "admin can write rooms" on public.rooms;
create policy "admin can write rooms" on public.rooms for insert to authenticated with check (public.is_admin());
drop policy if exists "admin can update rooms" on public.rooms;
create policy "admin can update rooms" on public.rooms for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin can delete rooms" on public.rooms;
create policy "admin can delete rooms" on public.rooms for delete to authenticated using (public.is_admin());

drop policy if exists "public can read active hotel_images" on public.hotel_images;
create policy "public can read active hotel_images" on public.hotel_images for select to anon, authenticated using (active = true or public.is_admin());
drop policy if exists "admin can write hotel_images" on public.hotel_images;
create policy "admin can write hotel_images" on public.hotel_images for insert to authenticated with check (public.is_admin());
drop policy if exists "admin can update hotel_images" on public.hotel_images;
create policy "admin can update hotel_images" on public.hotel_images for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin can delete hotel_images" on public.hotel_images;
create policy "admin can delete hotel_images" on public.hotel_images for delete to authenticated using (public.is_admin());

drop policy if exists "public can read active room_images" on public.room_images;
create policy "public can read active room_images" on public.room_images for select to anon, authenticated using (active = true or public.is_admin());
drop policy if exists "admin can write room_images" on public.room_images;
create policy "admin can write room_images" on public.room_images for insert to authenticated with check (public.is_admin());
drop policy if exists "admin can update room_images" on public.room_images;
create policy "admin can update room_images" on public.room_images for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin can delete room_images" on public.room_images;
create policy "admin can delete room_images" on public.room_images for delete to authenticated using (public.is_admin());

-- room_units are only ever read/written by admins directly; guest booking flow never touches this table
-- directly (it goes through the security-definer functions below).
drop policy if exists "admin can read room_units" on public.room_units;
create policy "admin can read room_units" on public.room_units for select to authenticated using (public.is_admin());
drop policy if exists "admin can write room_units" on public.room_units;
create policy "admin can write room_units" on public.room_units for all to authenticated using (public.is_admin()) with check (public.is_admin());


-- =====================================================================================
-- SECTION 4: TOURS, TOUR REQUESTS, TAXI REQUESTS
-- =====================================================================================
create table if not exists public.tours (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  duration text,
  price numeric(12,2) default 0,
  description text,
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.tours enable row level security;
drop policy if exists "public can read active tours" on public.tours;
create policy "public can read active tours" on public.tours for select to anon, authenticated using (active = true or public.is_admin());
drop policy if exists "admin can write tours" on public.tours;
create policy "admin can write tours" on public.tours for insert to authenticated with check (public.is_admin());
drop policy if exists "admin can update tours" on public.tours;
create policy "admin can update tours" on public.tours for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin can delete tours" on public.tours;
create policy "admin can delete tours" on public.tours for delete to authenticated using (public.is_admin());

create table if not exists public.tour_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  tour_id uuid references public.tours(id) on delete set null,
  guest_name text not null,
  phone text not null,
  email text,
  travel_date date,
  guests integer not null default 1,
  pickup text,
  notes text,
  created_at timestamptz not null default now()
);

alter table public.tour_requests enable row level security;
drop policy if exists "logged in users can create tour requests" on public.tour_requests;
create policy "logged in users can create tour requests"
  on public.tour_requests for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "user can read own tour requests" on public.tour_requests;
create policy "user can read own tour requests"
  on public.tour_requests for select to authenticated using (user_id = auth.uid() or public.is_admin());

create table if not exists public.taxi_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  guest_name text not null,
  phone text not null,
  pickup text not null,
  drop_location text not null,
  travel_date date not null,
  passengers integer not null default 1,
  service text,
  created_at timestamptz not null default now()
);

alter table public.taxi_requests enable row level security;
drop policy if exists "logged in users can create taxi requests" on public.taxi_requests;
create policy "logged in users can create taxi requests"
  on public.taxi_requests for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "user can read own taxi requests" on public.taxi_requests;
create policy "user can read own taxi requests"
  on public.taxi_requests for select to authenticated using (user_id = auth.uid() or public.is_admin());


-- =====================================================================================
-- SECTION 5: BOOKINGS
-- =====================================================================================
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  booking_ref text not null unique,
  hotel_id uuid references public.hotels(id) on delete set null,
  room_id uuid references public.rooms(id) on delete set null,
  room_unit_id uuid references public.room_units(id) on delete set null,
  guest_name text not null,
  phone text not null,
  email text,
  check_in date not null,
  check_out date not null,
  guests integer not null default 1,
  notes text,
  total_amount numeric(12,2) not null default 0,
  advance_amount numeric(12,2) not null default 0,
  balance_amount numeric(12,2) not null default 0,
  payment_status text not null default 'pending' check (payment_status in ('pending','submitted','paid','rejected','refunded')),
  payment_reference text,
  payment_submitted_at timestamptz,
  payment_verified_at timestamptz,
  payment_verified_by uuid references auth.users(id),
  status text not null default 'pending' check (status in ('pending','confirmed','cancelled')),
  confirm_note text,
  confirmed_at timestamptz,
  confirmed_by uuid references auth.users(id),
  whatsapp_notification_status text not null default 'pending',
  whatsapp_notification_error text,
  guest_whatsapp_status text,
  guest_whatsapp_error text,
  email_notification_status text,
  email_notification_error text,
  created_at timestamptz not null default now(),
  check (check_out > check_in)
);

create index if not exists bookings_room_id_idx on public.bookings(room_id);
create index if not exists bookings_booking_ref_idx on public.bookings(booking_ref);
create index if not exists bookings_payment_status_idx on public.bookings(payment_status);
create index if not exists bookings_created_at_idx on public.bookings(created_at desc);
create index if not exists bookings_dates_idx on public.bookings(room_id, check_in, check_out);

alter table public.bookings enable row level security;

-- Guests never read/write this table directly — everything guest-facing goes through the
-- security-definer functions in Section 7, which only expose the specific fields needed.
drop policy if exists "admin can read bookings" on public.bookings;
create policy "admin can read bookings" on public.bookings for select to authenticated using (public.is_admin());
drop policy if exists "admin can update bookings" on public.bookings;
create policy "admin can update bookings" on public.bookings for update to authenticated using (public.is_admin()) with check (public.is_admin());


-- =====================================================================================
-- SECTION 6: NOTIFICATIONS (admin activity feed) + auto-insert trigger
-- =====================================================================================
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null,
  created_at timestamptz not null default now()
);

alter table public.notifications enable row level security;
drop policy if exists "admin can read notifications" on public.notifications;
create policy "admin can read notifications" on public.notifications for select to authenticated using (public.is_admin());

create or replace function public.notify_booking_events()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.notifications(title, message)
    values ('New booking received', format('%s booked for %s → %s (Ref: %s)', new.guest_name, new.check_in, new.check_out, new.booking_ref));
  elsif tg_op = 'UPDATE' then
    if new.status = 'confirmed' and old.status is distinct from 'confirmed' then
      insert into public.notifications(title, message)
      values ('Booking confirmed', format('Ref %s confirmed for %s', new.booking_ref, new.guest_name));
    end if;
    if new.payment_status is distinct from old.payment_status then
      insert into public.notifications(title, message)
      values ('Payment status updated', format('Ref %s payment is now "%s"', new.booking_ref, new.payment_status));
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists on_booking_notify on public.bookings;
create trigger on_booking_notify
  after insert or update on public.bookings
  for each row execute function public.notify_booking_events();


-- =====================================================================================
-- SECTION 7: SECURITY-DEFINER FUNCTIONS (the only way guests touch bookings data)
-- =====================================================================================

-- 7a) Live availability for a room type over a date range.
create or replace function public.room_availability(
  p_room_id uuid,
  p_check_in date,
  p_check_out date
)
returns integer
language sql
stable
security definer
set search_path = public
as $$
  select greatest(
    (select count(*) from public.room_units where room_id = p_room_id and active = true)
    -
    (select count(*) from public.bookings
       where room_id = p_room_id
         and status <> 'cancelled'
         and check_in < p_check_out
         and check_out > p_check_in),
    0
  )::integer;
$$;

revoke all on function public.room_availability(uuid,date,date) from public;
grant execute on function public.room_availability(uuid,date,date) to anon, authenticated;


-- 7b) Guest creates a booking. Concurrency-safe: locks the room type for the duration of
-- the transaction so two guests booking the last room at the same instant can't both succeed.
create or replace function public.submit_guest_booking(
  p_guest_name text,
  p_phone text,
  p_email text,
  p_hotel_id uuid,
  p_room_id uuid,
  p_check_in date,
  p_check_out date,
  p_guests integer,
  p_notes text
)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare
  r public.rooms;
  nights integer;
  computed_total numeric(12,2);
  computed_advance numeric(12,2);
  new_ref text;
  b public.bookings;
  available integer;
begin
  if nullif(trim(p_guest_name),'') is null then raise exception 'Guest name is required'; end if;
  if nullif(trim(p_phone),'') is null then raise exception 'Phone number is required'; end if;
  if p_check_out <= p_check_in then raise exception 'Check-out must be after check-in'; end if;
  if p_check_in < current_date then raise exception 'Check-in cannot be in the past'; end if;
  if p_guests is null or p_guests < 1 then raise exception 'Guests must be at least 1'; end if;

  select * into r from public.rooms where id = p_room_id and hotel_id = p_hotel_id and active = true;
  if not found then raise exception 'Selected room is not available'; end if;
  if p_guests > r.capacity then raise exception 'This room allows a maximum of % guests', r.capacity; end if;

  -- Serialize concurrent bookings for the same room type until this transaction ends.
  perform pg_advisory_xact_lock(hashtextextended(p_room_id::text, 0));

  select public.room_availability(p_room_id, p_check_in, p_check_out) into available;
  if available < 1 then raise exception 'No rooms available for the selected dates'; end if;

  nights := p_check_out - p_check_in;
  computed_total := round(nights * r.price, 2);
  computed_advance := round(computed_total * 0.20, 2);

  -- Generate a unique booking reference, retrying on the rare collision.
  loop
    new_ref := 'HZ-' || to_char(now(), 'YYYY') || '-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6));
    exit when not exists (select 1 from public.bookings where booking_ref = new_ref);
  end loop;

  insert into public.bookings (
    booking_ref, hotel_id, room_id, guest_name, phone, email,
    check_in, check_out, guests, notes,
    total_amount, advance_amount, balance_amount,
    status, payment_status
  ) values (
    new_ref, p_hotel_id, p_room_id, trim(p_guest_name), trim(p_phone), nullif(trim(p_email),''),
    p_check_in, p_check_out, p_guests, nullif(trim(p_notes),''),
    computed_total, computed_advance, computed_total - computed_advance,
    'pending', 'pending'
  )
  returning * into b;

  return b;
end;
$$;

revoke all on function public.submit_guest_booking(text,text,text,uuid,uuid,date,date,integer,text) from public;
grant execute on function public.submit_guest_booking(text,text,text,uuid,uuid,date,date,integer,text) to anon, authenticated;


-- 7c) Guest looks up their own booking by reference + phone (no login required).
create or replace function public.booking_status_lookup(
  p_reference text,
  p_phone text
)
returns table (
  booking_ref text,
  status text,
  guest_name text,
  check_in date,
  check_out date,
  guests integer,
  hotel_name text,
  room_name text,
  total_amount numeric,
  payment_status text,
  allotted_room text
)
language sql
stable
security definer
set search_path = public
as $$
  select
    b.booking_ref, b.status, b.guest_name, b.check_in, b.check_out, b.guests,
    h.name, r.name, b.total_amount, b.payment_status, ru.room_number
  from public.bookings b
  left join public.hotels h on h.id = b.hotel_id
  left join public.rooms r on r.id = b.room_id
  left join public.room_units ru on ru.id = b.room_unit_id
  where b.booking_ref = trim(p_reference)
    and regexp_replace(b.phone, '\D', '', 'g') = regexp_replace(p_phone, '\D', '', 'g')
  limit 1;
$$;

revoke all on function public.booking_status_lookup(text,text) from public;
grant execute on function public.booking_status_lookup(text,text) to anon, authenticated;


-- 7d) Guest submits their UPI UTR/reference after paying the advance.
create or replace function public.submit_payment_reference(
  p_reference text,
  p_phone text,
  p_payment_reference text
)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare b public.bookings;
begin
  if nullif(trim(p_payment_reference),'') is null then
    raise exception 'Payment reference is required';
  end if;

  select * into b
  from public.bookings
  where booking_ref = trim(p_reference)
    and regexp_replace(phone,'\D','','g') = regexp_replace(p_phone,'\D','','g')
  limit 1;

  if not found then raise exception 'Booking not found'; end if;
  if b.payment_status = 'paid' then return b; end if;
  if b.status = 'cancelled' then raise exception 'Booking is cancelled'; end if;

  update public.bookings
  set payment_status = 'submitted',
      payment_reference = trim(p_payment_reference),
      payment_submitted_at = now()
  where id = b.id
  returning * into b;

  return b;
end;
$$;

revoke all on function public.submit_payment_reference(text,text,text) from public;
grant execute on function public.submit_payment_reference(text,text,text) to anon, authenticated;


-- 7e) Admin-only: mark an advance payment paid or rejected.
create or replace function public.admin_set_payment_status(
  p_booking_id uuid,
  p_status text,
  p_note text default null
)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare b public.bookings;
begin
  if not public.is_admin() then raise exception 'Admin access required'; end if;
  if p_status not in ('paid','rejected') then raise exception 'Invalid payment status'; end if;

  update public.bookings
  set payment_status = p_status,
      payment_verified_at = now(),
      payment_verified_by = auth.uid(),
      notes = case when nullif(trim(p_note),'') is null then notes else coalesce(notes,'') || E'\n' || trim(p_note) end
  where id = p_booking_id
  returning * into b;

  if not found then raise exception 'Booking not found'; end if;
  return b;
end;
$$;

revoke all on function public.admin_set_payment_status(uuid,text,text) from public;
grant execute on function public.admin_set_payment_status(uuid,text,text) to authenticated;


-- 7f) Admin-only: confirm a booking by allocating a specific physical room unit.
create or replace function public.admin_confirm_booking(
  p_booking_id uuid,
  p_room_unit_id uuid,
  p_note text default null
)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare
  b public.bookings;
  u public.room_units;
begin
  if not public.is_admin() then raise exception 'Admin access required'; end if;

  select * into b from public.bookings where id = p_booking_id;
  if not found then raise exception 'Booking not found'; end if;

  select * into u from public.room_units where id = p_room_unit_id and room_id = b.room_id and active = true;
  if not found then raise exception 'Room unit not found for this room type'; end if;

  update public.bookings
  set status = 'confirmed',
      room_unit_id = p_room_unit_id,
      confirmed_at = now(),
      confirmed_by = auth.uid(),
      confirm_note = nullif(trim(p_note),'')
  where id = p_booking_id
  returning * into b;

  return b;
end;
$$;

revoke all on function public.admin_confirm_booking(uuid,uuid,text) from public;
grant execute on function public.admin_confirm_booking(uuid,uuid,text) to authenticated;


-- 7g) Admin-only: set the target number of physical room units for a room type.
-- Existing units are never deleted; excess ones are just deactivated (never touches booked units).
create or replace function public.admin_sync_room_inventory(
  p_room_id uuid,
  p_total_rooms integer
)
returns setof public.room_units
language plpgsql
security definer
set search_path = public
as $$
declare
  current_count integer;
  next_no integer;
  target integer;
begin
  if not public.is_admin() then raise exception 'Admin access required'; end if;
  target := greatest(coalesce(p_total_rooms,0),0);

  if not exists (select 1 from public.rooms where id = p_room_id) then
    raise exception 'Room type not found';
  end if;

  select count(*) into current_count from public.room_units where room_id = p_room_id;

  if current_count < target then
    next_no := 1;
    while current_count < target loop
      while exists (select 1 from public.room_units where room_id = p_room_id and room_number = next_no::text) loop
        next_no := next_no + 1;
      end loop;
      insert into public.room_units(room_id, room_number, status, active)
      values (p_room_id, next_no::text, 'available', true);
      current_count := current_count + 1;
      next_no := next_no + 1;
    end loop;
  end if;

  update public.room_units
  set active = true
  where id in (
    select id from public.room_units
    where room_id = p_room_id and active = false
    order by room_number
    limit greatest(target - (select count(*) from public.room_units where room_id = p_room_id and active = true), 0)
  );

  update public.room_units
  set active = false
  where id in (
    select id from public.room_units
    where room_id = p_room_id and active = true
    order by room_number desc
    offset target
  );

  update public.rooms
  set total_rooms = (select count(*) from public.room_units where room_id = p_room_id and active = true)
  where id = p_room_id;

  return query select * from public.room_units where room_id = p_room_id order by room_number;
end;
$$;

revoke all on function public.admin_sync_room_inventory(uuid,integer) from public;
grant execute on function public.admin_sync_room_inventory(uuid,integer) to authenticated;


-- =====================================================================================
-- SECTION 8: SITE SETTINGS (contact info + UPI, shown on the website)
-- =====================================================================================
create table if not exists public.site_settings (
  key text primary key,
  value jsonb not null
);

alter table public.site_settings enable row level security;
drop policy if exists "public can read site_settings" on public.site_settings;
create policy "public can read site_settings" on public.site_settings for select to anon, authenticated using (true);
drop policy if exists "admin can write site_settings" on public.site_settings;
create policy "admin can write site_settings" on public.site_settings for insert to authenticated with check (public.is_admin());
drop policy if exists "admin can update site_settings" on public.site_settings;
create policy "admin can update site_settings" on public.site_settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

insert into public.site_settings (key, value)
values ('contact', jsonb_build_object(
  'phone', '9805793737',
  'whatsapp', '7559772533',
  'upi', '9805793737@ptsbi',
  'payee_name', 'Manoj Sharma'
))
on conflict (key) do nothing;


-- =====================================================================================
-- SECTION 9: VISITOR LEADS (WhatsApp quote popup + Admin > Visitor Leads tab)
-- =====================================================================================
create table if not exists public.site_leads (
  id uuid primary key default gen_random_uuid(),
  guest_name text,
  phone text not null,
  source text not null default 'website_popup',
  status text not null default 'new' check (status in ('new','contacted','converted','closed')),
  created_at timestamptz not null default now()
);

create index if not exists site_leads_created_at_idx on public.site_leads(created_at desc);

alter table public.site_leads enable row level security;
drop policy if exists "anon can submit leads" on public.site_leads;
create policy "anon can submit leads" on public.site_leads for insert to anon, authenticated with check (true);
drop policy if exists "admin can view leads" on public.site_leads;
create policy "admin can view leads" on public.site_leads for select to authenticated using (public.is_admin());
drop policy if exists "admin can update leads" on public.site_leads;
create policy "admin can update leads" on public.site_leads for update to authenticated using (public.is_admin()) with check (public.is_admin());


-- =====================================================================================
-- SECTION 10: STORAGE (photo/video uploads for hotels & rooms)
-- =====================================================================================
insert into storage.buckets (id, name, public)
values ('site-assets', 'site-assets', true)
on conflict (id) do nothing;

drop policy if exists "public can view site-assets" on storage.objects;
create policy "public can view site-assets"
  on storage.objects for select
  using (bucket_id = 'site-assets');

drop policy if exists "admin can upload site-assets" on storage.objects;
create policy "admin can upload site-assets"
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'site-assets' and public.is_admin());

drop policy if exists "admin can update site-assets" on storage.objects;
create policy "admin can update site-assets"
  on storage.objects for update
  to authenticated
  using (bucket_id = 'site-assets' and public.is_admin())
  with check (bucket_id = 'site-assets' and public.is_admin());

drop policy if exists "admin can delete site-assets" on storage.objects;
create policy "admin can delete site-assets"
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'site-assets' and public.is_admin());


-- =====================================================================================
-- SECTION 11: REALTIME (so the Admin panel updates live without refreshing)
-- =====================================================================================
do $$ begin alter publication supabase_realtime add table public.bookings; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.site_leads; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.notifications; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.hotels; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.rooms; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.hotel_images; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.room_images; exception when others then null; end $$;


-- =====================================================================================
-- SECTION 12: STARTER SAMPLE DATA (only inserted if you have zero hotels — safe to re-run)
-- =====================================================================================
do $$
declare
  sample_hotel_id uuid;
  sample_room_id uuid;
begin
  if not exists (select 1 from public.hotels) then
    insert into public.hotels (name, location, address, phone, description, amenities, active, image_url)
    values (
      'Sample Hotel — edit me in Admin',
      'Mall Road, Shimla',
      'Near Ridge, Mall Road, Shimla, HP',
      '9805793737',
      'Replace this description from the Admin > Hotels tab. Add real photos there too.',
      array['Free WiFi','Mountain View','24x7 Front Desk'],
      true,
      'assets/shimla-winter.jpg'
    )
    returning id into sample_hotel_id;

    -- Seed the hotel-level photo slider with the site's own uploaded images, so "View Rooms"
    -- shows a working multi-photo slider immediately, with no admin upload needed first.
    insert into public.hotel_images (hotel_id, image_url, alt_text, sort_order, active)
    values
      (sample_hotel_id, 'assets/shimla-winter.jpg', 'Shimla winter view', 0, true),
      (sample_hotel_id, 'assets/shimla-cablecar.jpg', 'Shimla cable car', 1, true);

    insert into public.rooms (hotel_id, name, price, capacity, bed_type, total_rooms, active, sort_order, image_url)
    values (sample_hotel_id, 'Deluxe Room', 2500, 2, 'Double Bed', 3, true, 0, 'assets/shimla-cablecar.jpg')
    returning id into sample_room_id;

    -- Seed the per-room photo slider too (this is the slider that previously never opened).
    insert into public.room_images (room_id, image_url, alt_text, sort_order, active)
    values
      (sample_room_id, 'assets/shimla-cablecar.jpg', 'Deluxe Room view', 0, true),
      (sample_room_id, 'assets/shimla-winter.jpg', 'Deluxe Room — winter view', 1, true);

    insert into public.room_units (room_id, room_number, status, active)
    values
      (sample_room_id, '1', 'available', true),
      (sample_room_id, '2', 'available', true),
      (sample_room_id, '3', 'available', true);
  end if;
end $$;

-- =====================================================================================
-- DONE. Next steps:
-- 1. Sign up once on the website (Login → Create New Account), then in this SQL editor run:
--      update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'YOUR_EMAIL');
-- 2. Log in again on the website — the Admin Panel section will appear.
-- 3. Edit the sample hotel/room from Admin, or delete it and add your real ones.
-- 4. (Optional) Follow supabase/functions/readme.md to enable automatic WhatsApp/email
--    notifications — the website works fully without this step too.
-- =====================================================================================
